# Run Recap Forever

🇩🇪 [Deutsche Version](README.de.md)

An addon for **WoW Forever**: after the last boss of a dungeon, a summary of your run opens:
- which bosses you killed, and when
- who got which item from which boss
- fun facts about the run: duration, deaths, wipes, gold

> **Current version: 1.0.0** – on CurseForge.

Author: **Ibona93** · License: MIT (see [`LICENSE`](LICENSE); bundled fonts: SIL OFL 1.1; bundled libraries in `Libs/`: LibStub, CallbackHandler-1.0, LibDataBroker-1.1, LibDBIcon-1.0 under their own licenses)
Game version: WoW Forever **1.60.1, Interface 16001**

Sister addon: [BGF – Better Group Finder Forever](https://github.com/Ibona93/BetterGroupFinder)

---

## 1. Installation

1. Close the game (or type `/reload` afterwards).
2. Unzip the file. You get a folder named `RunRecap`.
3. Copy this folder into the `Interface\AddOns` folder of your WoW Forever client.
4. The folder must contain `RunRecap.toc` directly. `RunRecap\RunRecap\…` does not work.
5. On the character selection screen, open **AddOns** and enable "Run Recap Forever".

## 2. How it works

- **Run start:** when you enter a dungeon (all 28 dungeons, including the Forever dungeons).
- **Completed:** when every required boss is dead (any order) or the end boss is dead. Optional and rare bosses don't count. Scarlet Monastery, Dire Maul, Stratholme and Blackrock Spire count per wing.
- **Success moment:** a sound (default "Quest complete"), then a "Dungeon completed!" banner for a few seconds, then the recap (after combat). Click the banner to skip it.
- **Recap:** on the left the bosses with the minute in the run and fight duration, below each the loot and who got it; uncertain sources under "? probably from this boss", loot from normal enemies under "Trash". On the right duration, bosses, wipes, gold, deaths and highlights.
- **Tooltips:** item name → the normal item tooltip plus looter and source. Rest of the row → who won; hold **Shift** for all rolls. Boss row with Shift → wipes, deaths in the fight, number of items.
- **Leaving the instance:** as a ghost the run keeps going; alive (e.g. hearthstone to a vendor) it is paused. It ends when you enter another instance, when the instance is reset, or after 30 minutes outside.
- Aborted runs get no recap.

## 3. Commands

| Command | Effect |
|---|---|
| `/recap` | Open/close the recap of the last completed run |
| `/recap options` | Open the options (also under Options → AddOns) |
| `/recap demo` | Preview: sound, banner and recap with a made-up run |
| `/recap tour` | Restart the introduction |
| `/recap news` | Show "What's new" (all release notes via the version badge) |
| `/recap debug` | Debug output on/off, shows version, client build, interface number and the current run |
| `/recap help` | List the commands |

Minimap button: left-click opens the recap of the last run (of the character you are playing; option "Show runs of all characters" for all), right-click the options; it can be dragged around the minimap and hidden in the options. Minimap button collectors and broker bars (Titan Panel, ChocolateBar) pick it up.

**Options:** open automatically (on/off), show green items too (default: blue and better), show runs of all characters (default: only the character you are playing), look (Blizzard or Run Recap), success sound (7 game sounds or off, with preview), preview.

## 4. Known limitations

- The addon only sees what your own client sees: loot of other players only while you are nearby and in the group.
- The addon knows an item's source for sure from your own loot window and from rolls right after a boss kill. If another player takes an item without a roll, the source is only "probably". Items with a known source are remembered.
- If you join in the middle of a run, the recap starts where you joined.

## 5. Feedback and contributing

Bug reports and ideas: [GitHub Issues](https://github.com/Ibona93/RunRecap/issues). Technical notes and tests: [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md).

## 6. Changelog

### 1.0.2 (25.11.2026)
- Runs per character: `/recap` and the minimap button show the last run of the character you are playing, no longer your main's run on an alt. Runs from before 1.0.2 are shown for every character. The last 20 runs are kept per character.
- New option "Show runs of all characters" (off by default): shows the account's last run as before, with the character's name in the recap.

### 1.0.1 (25.11.2026)
- Fixed: rolls on items whose name contains the roll line's own words (in German e.g. "[Mantel von Doan]") were stored under wrong player names – the run facts then listed made-up players under "Deaths". Runs saved with this error are repaired automatically.
- "Deaths" shows at most 5 players, the rest as "+N more" (hover it for the full list). The run facts no longer run into the highlights.

### 1.0.0 (24.11.2026)
- First version: recap after the last boss with bosses (minute in the run, fight duration, end boss), loot per boss with the looter in class colour, a "Trash" section and run facts (duration, bosses, wipes, your gold, vendor value of your loot, repair costs and balance, deaths, highlights).
- Success moment: sound and "Dungeon completed!" banner, then the recap.
- Rolls: who won, and with Shift every roll.
- Rare elites appear when killed (tagged "rare"); gold from quests handed in inside the dungeon counts.
- Introduction on the first start, "What's new" after every update (German/English).
- All 28 dungeons, including the 9 new Forever dungeons (wings for Scarlet Monastery, Dire Maul, Stratholme and Blackrock Spire).
- Two looks: Blizzard (default) or Run Recap (dark & gold); options: open automatically, green items, look, success sound, preview. Texts in 10 languages.
